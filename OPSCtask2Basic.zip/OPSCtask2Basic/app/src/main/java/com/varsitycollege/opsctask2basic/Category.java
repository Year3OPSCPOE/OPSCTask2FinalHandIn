package com.varsitycollege.opsctask2basic;

import android.widget.EditText;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.IgnoreExtraProperties;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
/*                                 Ignore this class, was just testing something
@IgnoreExtraProperties
public class Category
{

    public String CarName;
    public String CategoryName;
    public String Description;
    public Date DateSeen;

    MainActivity ss = new MainActivity();
    // Getter
    public EditText getCarName() {
        return ss.CarName;
    }

    // Setter
    public void setCarName(String newCarName) {
        this.ss.CarName = newCarName;
    }

    public Category()
    {
        // Default constructor required for calls to DataSnapshot.getValue(User.class)
    }

    public Category(String CarName, String CategoryName, String Description, Date DateSeen) {
        this.CarName = CarName;
        this.CategoryName = CategoryName;
        this.Description = Description;
        this.DateSeen = DateSeen;
    }

    @Exclude
    public Map<String, Object> toMap() {
        HashMap<String, Object> result = new HashMap<>();
        result.put("Car Name", CarName);
        result.put("Description", Description);
        result.put("Date Seen", DateSeen);
        return result;
    }

}*/
