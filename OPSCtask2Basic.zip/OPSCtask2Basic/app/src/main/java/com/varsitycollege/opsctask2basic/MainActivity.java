package com.varsitycollege.opsctask2basic;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {


    EditText CategoryName;
    EditText CarName;
    EditText Description;
    Spinner CategorySelect;
    EditText DateSeen;
    String TAG = "Firebase";
    private DatabaseReference mDatabase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CategoryName = findViewById(R.id.txtCategory);
        CarName = findViewById(R.id.txtCarName);
        Description = findViewById(R.id.txtDescription);
        DateSeen = findViewById(R.id.dtSeen);
        Spinner CategorySelect = findViewById(R.id.spCategorySelect);
        //Variable
        Spinner CategorySelected = (Spinner) findViewById(R.id.spCategorySelect);
        String stCategoryName = CategoryName.getText().toString();
        String stCarName = CarName.getText().toString();
        String stDescription = Description.getText().toString();
        String stDateSeen = DateSeen.getText().toString();
        //Creates Variable for the selected item in the drop down box
        CategorySelected.setOnItemSelectedListener(this.CategorySelected);



        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                String value = dataSnapshot.getValue(String.class);
                Log.d(TAG, "Value is: " + value);
            }

            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
                Log.w(TAG, "Failed to read value.", error.toException());
            }
        });
        //Sends string varibles to Category constructor
        new Category(stCategoryName, stCarName, stDescription, stDateSeen);
    }



    @IgnoreExtraProperties
    public class Category {


        private String stCategoryName;
        private String stCarName;
        private String stDescription;
        private String stDateSeen;

        public Category() {
            //Default constructor required for calls to DataSnapshot.getValue(User.class)
        }

        public Category(String stCategoryName, String stCarName, String stDescription, String stDateSeen) {
            this.stCategoryName = stCategoryName;
            this.stCarName = stCarName;
            this.stDescription = stDescription;
            this.stDateSeen = stDateSeen;
        }
        //Create Map for adding cars
        @Exclude
        public Map<String, Object> toMap() {
            HashMap<String, Object> result = new HashMap<>();
            result.put("Car Name", stCarName);
            result.put("Description", stDescription);
            result.put("Date Seen", stDateSeen);
            return result;
        }

        //}
        //send Category name to database
        private void writeNewCategory() {
            Category gat = new Category();
            mDatabase = FirebaseDatabase.getInstance().getReference();

//        Category category = new Category(CarName, CategoryName, Description, DateSeen);

            mDatabase.child(String.valueOf(stCategoryName)).setValue(stCategoryName);
        }

        //Button press that class methods, was working
        public void setCateGory(View view) {

            writeNewCategory();
            addToSpinner();
            ReadDb();

        }

        private void addToSpinner() {
             //Method that adds gategory names to drop down box spinner
            Category gat = new Category();
            String[] Categories = {gat.stCategoryName};
            ArrayAdapter ad = new ArrayAdapter(this,android.R.layout.simple_spinner_item, Categories);

            // set simple layout resource file
            // for each item of spinner
            ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            // Set the ArrayAdapter (ad) data on the
            // Spinner which binds data to spinner
            CategorySelect.setAdapter(ad);

        }

        class SelectedCategory {
            //class that turn selected category in the drop down box to a string
            String CategorySelected = CategorySelect.getSelectedItem().toString();
        }

        //Button press that calls add cars
        public void addCar(View view) {
            addCars();
        }

        public void addCars() {
            //Updates a category with the cars information
            SelectedCategory ads = new SelectedCategory();
            Category category = new Category(stCarName, stCategoryName, stDescription, stDateSeen);
            String key = mDatabase.child("posts").push().getKey();


            Map<String, Object> postValues = category.toMap();

            Map<String, Object> childUpdates = new HashMap<>();
            childUpdates.put("/posts/" + key, postValues);
            childUpdates.put("/user-posts/" + stCarName + "/" + CategoryName + "/" + Description + "/" + DateSeen + "/" + key, postValues);

            mDatabase.updateChildren(childUpdates);

        }

        //private void writeNewPost(String CarName, String username, String title, String body) {
        // Create new post at /user-posts/$userid/$postid and at
        // /posts/$postid simultaneously
//        Post post = new Post(userId, username, title, body);
        //Map<String, Object> postValues = post.toMap();

        // Map<String, Object> childUpdates = new HashMap<>();
        // childUpdates.put("/posts/" + key, postValues);
        //  childUpdates.put("/user-posts/" + userId + "/" + key, postValues);

        //mDatabase.updateChildren(childUpdates);

        public void ReadDb() {
            //Reads database on screen 
            Category gat = new Category();
            final Task<DataSnapshot> dataSnapshotTask = mDatabase.child(String.valueOf(gat.stCategoryName)).child(String.valueOf(gat.stCategoryName)).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DataSnapshot> task) {
                    if (!task.isSuccessful()) {
                        Log.e("firebase", "Error getting data", task.getException());
                    } else {
                        Log.d("firebase", String.valueOf(task.getResult().getValue()));
                    }
                }
            });

        }

        ;


    }
}
   






