package com.example.opsc_poe;public class Constants {
}
