package com.example.opsc_poe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AddItemActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);
    }
}