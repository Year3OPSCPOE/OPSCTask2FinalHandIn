package com.varsitycollege.task2opscloginandregister;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomePage extends AppCompatActivity {
    private Button btnPhotoGallery;
    private Button btnCollection;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        btnPhotoGallery = (Button) (findViewById(R.id.btnPhotoGallery));
        btnPhotoGallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openPhotoGallery();
            }
        });

       /* btnCollection = (Button) (findViewById(R.id.btnCollection));
        btnCollection.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCollection();
            }
        }); */
    }

    public void openPhotoGallery(){
        Intent intent = new Intent(this, PhotoGallery.class);
        startActivity(intent);
    }

  /*  public void openCollection(){
        Intent intent = new Intent(this, Collections.class);
        startActivity(intent);
    }*/
}